---
name: "ai-research-skills-part-001"
description: "ai-research-skills: part 1/3, 45 modules. Use bundled modules only; CLOUD-PART.json routes the complete library."
---

# ai-research-skills: cloud part 1/3

Read [host runtime](yigit/host-runtime.md) and [part boundaries](CLOUD-README.md).

The complete library spans every part listed in CLOUD-PART.json. This part contains only the modules below.
Preserved complete entrypoint: [reference only](yigit/complete-host-entrypoint.md); links to other parts are not local files.

- [a-evolve](modules/a-evolve/MODULE.md)
- [academic-plotting](modules/academic-plotting/MODULE.md)
- [accelerate](modules/accelerate/MODULE.md)
- [audiocraft](modules/audiocraft/MODULE.md)
- [autogpt](modules/autogpt/MODULE.md)
- [autoresearch](modules/autoresearch/MODULE.md)
- [awq](modules/awq/MODULE.md)
- [axolotl](modules/axolotl/MODULE.md)
- [bigcode-evaluation-harness](modules/bigcode-evaluation-harness/MODULE.md)
- [bitsandbytes](modules/bitsandbytes/MODULE.md)
- [blip-2](modules/blip-2/MODULE.md)
- [brainstorming-research-ideas](modules/brainstorming-research-ideas/MODULE.md)
- [chroma](modules/chroma/MODULE.md)
- [clip](modules/clip/MODULE.md)
- [compiler](modules/compiler/MODULE.md)
- [constitutional-ai](modules/constitutional-ai/MODULE.md)
- [cosmos-policy](modules/cosmos-policy/MODULE.md)
- [creative-thinking-for-research](modules/creative-thinking-for-research/MODULE.md)
- [crewai](modules/crewai/MODULE.md)
- [deepspeed](modules/deepspeed/MODULE.md)
- [dspy](modules/dspy/MODULE.md)
- [faiss](modules/faiss/MODULE.md)
- [flash-attention](modules/flash-attention/MODULE.md)
- [gguf](modules/gguf/MODULE.md)
- [gptq](modules/gptq/MODULE.md)
- [grpo-rl-training](modules/grpo-rl-training/MODULE.md)
- [guidance](modules/guidance/MODULE.md)
- [hqq](modules/hqq/MODULE.md)
- [huggingface-tokenizers](modules/huggingface-tokenizers/MODULE.md)
- [instructor](modules/instructor/MODULE.md)
- [knowledge-distillation](modules/knowledge-distillation/MODULE.md)
- [lambda-labs](modules/lambda-labs/MODULE.md)
- [langchain](modules/langchain/MODULE.md)
- [langsmith](modules/langsmith/MODULE.md)
- [litgpt](modules/litgpt/MODULE.md)
- [llama-cpp](modules/llama-cpp/MODULE.md)
- [llama-factory](modules/llama-factory/MODULE.md)
- [llamaguard](modules/llamaguard/MODULE.md)
- [llamaindex](modules/llamaindex/MODULE.md)
- [llava](modules/llava/MODULE.md)
- [lm-evaluation-harness](modules/lm-evaluation-harness/MODULE.md)
- [long-context](modules/long-context/MODULE.md)
- [mamba](modules/mamba/MODULE.md)
- [megatron-core](modules/megatron-core/MODULE.md)
- [miles](modules/miles/MODULE.md)
