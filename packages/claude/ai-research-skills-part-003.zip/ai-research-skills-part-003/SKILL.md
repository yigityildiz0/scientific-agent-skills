---
name: "ai-research-skills-part-003"
description: "ai-research-skills: part 3/3, 16 modules. Use bundled modules only; CLOUD-PART.json routes the complete library."
---

# ai-research-skills: cloud part 3/3

Read [host runtime](yigit/host-runtime.md) and [part boundaries](CLOUD-README.md).

The complete library spans every part listed in CLOUD-PART.json. This part contains only the modules below.
Preserved complete entrypoint: [reference only](yigit/complete-host-entrypoint.md); links to other parts are not local files.

- [slime](modules/slime/MODULE.md)
- [speculative-decoding](modules/speculative-decoding/MODULE.md)
- [stable-diffusion](modules/stable-diffusion/MODULE.md)
- [swanlab](modules/swanlab/MODULE.md)
- [systems-paper-writing](modules/systems-paper-writing/MODULE.md)
- [tensorboard](modules/tensorboard/MODULE.md)
- [tensorrt-llm](modules/tensorrt-llm/MODULE.md)
- [torchforge](modules/torchforge/MODULE.md)
- [torchtitan](modules/torchtitan/MODULE.md)
- [transformer-lens](modules/transformer-lens/MODULE.md)
- [trl-fine-tuning](modules/trl-fine-tuning/MODULE.md)
- [unsloth](modules/unsloth/MODULE.md)
- [verl](modules/verl/MODULE.md)
- [vllm](modules/vllm/MODULE.md)
- [weights-and-biases](modules/weights-and-biases/MODULE.md)
- [whisper](modules/whisper/MODULE.md)
