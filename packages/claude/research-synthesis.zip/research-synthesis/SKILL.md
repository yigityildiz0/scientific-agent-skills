---
name: research-synthesis
description: "Synthesize qualitative research, feedback, interviews, observations, support tickets, or study notes into traceable themes, evidence, uncertainty, and actionable opportunities. Use for."
---

# Research Synthesis

Preserve the path from raw evidence to conclusion.

1. Define the decision, corpus, participant/source coverage, and limitations.
2. Normalize notes into atomic observations with source IDs; keep quotations short and contextual.
3. Group patterns by behavior or need, not by a preferred solution.
4. Distinguish frequency, intensity, impact, and confidence; surface contradictory evidence.
5. Produce findings, supporting evidence, opportunity hypotheses, and validation next steps.

Do not turn a memorable quote into a universal truth, erase minority signals, or disclose participant identifiers.
