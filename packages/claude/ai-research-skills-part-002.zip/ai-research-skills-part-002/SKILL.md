---
name: "ai-research-skills-part-002"
description: "ai-research-skills: part 2/3, 37 modules. Use bundled modules only; CLOUD-PART.json routes the complete library."
---

# ai-research-skills: cloud part 2/3

Read [host runtime](yigit/host-runtime.md) and [part boundaries](CLOUD-README.md).

The complete library spans every part listed in CLOUD-PART.json. This part contains only the modules below.
Preserved complete entrypoint: [reference only](yigit/complete-host-entrypoint.md); links to other parts are not local files.

- [ml-paper-writing](modules/ml-paper-writing/MODULE.md)
- [ml-training-recipes](modules/ml-training-recipes/MODULE.md)
- [mlflow](modules/mlflow/MODULE.md)
- [modal](modules/modal/MODULE.md)
- [model-merging](modules/model-merging/MODULE.md)
- [model-pruning](modules/model-pruning/MODULE.md)
- [moe-training](modules/moe-training/MODULE.md)
- [nanogpt](modules/nanogpt/MODULE.md)
- [nemo-curator](modules/nemo-curator/MODULE.md)
- [nemo-evaluator](modules/nemo-evaluator/MODULE.md)
- [nemo-guardrails](modules/nemo-guardrails/MODULE.md)
- [nnsight](modules/nnsight/MODULE.md)
- [openpi](modules/openpi/MODULE.md)
- [openrlhf](modules/openrlhf/MODULE.md)
- [openvla-oft](modules/openvla-oft/MODULE.md)
- [outlines](modules/outlines/MODULE.md)
- [peft](modules/peft/MODULE.md)
- [phoenix](modules/phoenix/MODULE.md)
- [pinecone](modules/pinecone/MODULE.md)
- [presenting-conference-talks](modules/presenting-conference-talks/MODULE.md)
- [prompt-guard](modules/prompt-guard/MODULE.md)
- [pytorch-fsdp2](modules/pytorch-fsdp2/MODULE.md)
- [pytorch-lightning](modules/pytorch-lightning/MODULE.md)
- [pyvene](modules/pyvene/MODULE.md)
- [qdrant](modules/qdrant/MODULE.md)
- [ray-data](modules/ray-data/MODULE.md)
- [ray-train](modules/ray-train/MODULE.md)
- [research-manager](modules/research-manager/MODULE.md)
- [rigor-reviewer](modules/rigor-reviewer/MODULE.md)
- [rwkv](modules/rwkv/MODULE.md)
- [saelens](modules/saelens/MODULE.md)
- [segment-anything](modules/segment-anything/MODULE.md)
- [sentence-transformers](modules/sentence-transformers/MODULE.md)
- [sentencepiece](modules/sentencepiece/MODULE.md)
- [sglang](modules/sglang/MODULE.md)
- [simpo](modules/simpo/MODULE.md)
- [skypilot](modules/skypilot/MODULE.md)
