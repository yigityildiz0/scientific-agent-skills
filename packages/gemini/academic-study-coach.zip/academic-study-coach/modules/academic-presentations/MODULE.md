# Module: academic-presentations

> Part of the `academic-study-coach` skill. Paths below are relative to this module folder (`modules/academic-presentations/`).
> Original trigger scope: Plan, write, review, or improve academic presentations for thesis defenses, conferences, seminars, lab meetings, grant briefings, and research talks. Use when evidence, argument flow, citations, methods, results, and scholarly presentation quality matter. Turkish triggers: tez sunumu, akademik sunum, konferans konuşması, sunumu iyileştir.

# Academic Presentations

Use this module for the scholarly argument layer only. Building the deck — brief and course rules, slide plan, real images, PPTX via the deck kit, speaker notes, rendered QA, audit and delivery — belongs to the `presentation-studio` skill. Hand over: audience, time, the claim, action titles, evidence per slide and verified references; do not leave layout or production to an unspecified "host capability".

## Build the argument first

1. Identify audience, time limit, decision or claim, evidence base, and institution/venue constraints.
2. Draft action titles: each title states the slide’s takeaway as a complete claim, not a topic label.
3. Run the ghost-deck test: read titles in order. They must tell a defensible argument without the speaker notes.
4. Give each results slide one primary exhibit and one explicit interpretation. Move secondary evidence to appendix.
5. Keep methods sufficient for credibility, not a transcript of the protocol.

## Academic quality checks

- Distinguish result, interpretation, limitation, and speculation.
- Cite borrowed figures, datasets, quotes, and claims on the relevant slide; include a final reference list.
- Preserve uncertainty, sample sizes, comparators, and relevant assumptions.
- End with conclusions and the next scientific question; keep Q&A material available rather than ending on an empty thank-you slide.
- Match an approved institution template when one exists; otherwise use a restrained, readable academic visual system.

## Review sequence

1. Argument and evidence review.
2. Timing review: remove material before shrinking text.
3. Accessibility review: reading order, contrast, legible type, and chart annotations.
4. Rendered visual QA and audit with `presentation-studio` (`scripts/render_pptx.ps1`, `scripts/pptx_audit.py`).

## Guardrails

- Do not invent citations, results, statistical significance, or permissions.
- Do not convert a research talk into a decorative marketing deck.
- Keep unpublished or participant-sensitive data within the user’s authorized scope.
